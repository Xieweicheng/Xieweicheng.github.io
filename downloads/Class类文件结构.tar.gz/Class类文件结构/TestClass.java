package org.fenixsoft.clazz;
	public class TestClass{
	private int m;
	public int inc(){
		return m+1;
	}
}