package cn.mrxiexie.jni;

import java.util.Arrays;
import java.util.Random;

public class JNI {

    static {
        try {
            // 此处即为本地方法所在链接库名
            System.loadLibrary("JNI");
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Cannot load JNI library:\n " + e.toString());
        }
    }

    public static native double[] sqrt(int[] nums);

    public static native int max();

    public native int min();

    public static void log(String msg) {
        System.out.println("In C " + msg);
    }

    public static int[] getNums(int count) {
        int[] nums = new int[count];
        Random random = new Random();
        for (int i = 0; i < count; i++) {
            nums[i] = random.nextInt(count);
        }
        System.out.println("In Java getNums ： " + Arrays.toString(nums));
        return nums;
    }

    public static void main(String[] args) {
        JNI jni = new JNI();
        int max = max();
        System.out.println("In Java max num is " + max);
        int min = jni.min();
        System.out.println("In Java min num is " + min);
        int[] nums = JNI.getNums(10);
        double[] sqrt = sqrt(nums);
        System.out.println("In Java sqrt num is " + Arrays.toString(sqrt));
    }
}